.. _representations:

Representations
===============

In this section, we summarize the representations implemented in Rascal.

.. contents::
   :local:

Pair distances
**************

SphericalInvariants
*******************

Behler-Parinello symmetry functions
***********************************

Based on [Behler2007]_

Voronoi representation
**********************

Coulomb matrices
****************
