.. _models:

Models
======

A summary of the prediction models implemented in Rascal.

.. contents::
   :local:

Regression
~~~~~~~~~~

Neural Networks
***************

