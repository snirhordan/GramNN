.. _auto:

API reference
=============

For more details about the methods, the interfaces and the classes implemented
in Rascal, please check the following:

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   python
   cpp
